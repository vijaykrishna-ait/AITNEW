<?php
$page_title     = 'Life with AIT | Adhiran Infotech';
$page_desc      = 'Website design and development company in chennai, web application development company in chennai | mobile app development company | offshoring company in chennai | hire software developer in chennai';
$page_keywords  = 'website design and development company in chennai, corporate branding development company in chennai, mobile app development company in chennai, e-commerce website development company in chennai, digital marketing company in Chennai, offshoring company in chennai, Seo company in chennai, hire software developers from chennai, hire software developers in  chennai, adhiran infotech, adhiran infotech in chennai, adhiran, adhiran software company, hire software developers';
$page_canonical = 'https://adhiraninfotech.com/';
include 'includes/header.php';
?>

<!-- LWA HERO -->
<section class="lwa-hero">
  <div class="wrap">
    <div class="eyebrow">Life with AIT</div>
    <h1>What it's really like to work at Adhiran Infotech</h1>
    <p class="lead-text">From team outings across our global offices to the benefits that support our people day to day — here's a look inside our culture.</p>
  </div>
</section>

<!-- GALLERY -->
<section style="padding-top:0;">
  <div class="wrap">
    <div class="life-gallery">
      <a href="<?= $base ?>#"><img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=600&q=80" alt="Team collaborating in office"></a>
      <a href="<?= $base ?>#"><img src="https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=600&q=80" alt="Team celebrating together"></a>
      <a href="<?= $base ?>#"><img src="https://images.unsplash.com/photo-1543269865-cbf427effbad?auto=format&fit=crop&w=600&q=80" alt="Office event"></a>
      <a href="<?= $base ?>#"><img src="https://images.unsplash.com/photo-1517048676732-d65bc937f952?auto=format&fit=crop&w=600&q=80" alt="Team brainstorming session"></a>
      <a href="<?= $base ?>#"><img src="https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=600&q=80" alt="Colleagues having a discussion"></a>
      <a href="<?= $base ?>#"><img src="https://images.unsplash.com/photo-1556761175-5973dc0f32e7?auto=format&fit=crop&w=600&q=80" alt="Team working together on a project"></a>
    </div>
  </div>
</section>

<!-- BENEFITS -->
<section>
  <div class="wrap">
    <div class="section-head">
      <div class="eyebrow">Benefits</div>
      <h2>What you get as part of the AIT team</h2>
      <p>Wherever you're based — India, USA, UAE, Singapore, Japan or Australia — our benefits are designed to support your work and your life.</p>
    </div>
    <div class="benefits-grid">
      <div class="benefit-card">
        <div class="ico"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg></div>
        <h3>Health &amp; Wellness Cover</h3>
        <p>Comprehensive medical insurance for employees and dependents, plus access to wellness programs.</p>
      </div>
      <div class="benefit-card">
        <div class="ico"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></div>
        <h3>Flexible Working</h3>
        <p>Hybrid and remote options across most roles, with flexibility to work across time zones.</p>
      </div>
      <div class="benefit-card">
        <div class="ico"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg></div>
        <h3>Learning &amp; Certifications</h3>
        <p>Sponsored certifications across AWS, Azure, Salesforce, SAP and more — plus internal learning programs.</p>
      </div>
      <div class="benefit-card">
        <div class="ico"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><path d="M18.4 8.6 13 14l-3-3-4.5 4.5"/></svg></div>
        <h3>Performance Bonuses</h3>
        <p>Transparent performance reviews tied to bonuses and clear paths for career progression.</p>
      </div>
      <div class="benefit-card">
        <div class="ico"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg></div>
        <h3>Global Mobility</h3>
        <p>Opportunities to work on projects across our India, US, UAE, Singapore, Japan and Australia offices.</p>
      </div>
      <div class="benefit-card">
        <div class="ico"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2 4 5v6c0 5 3.5 9 8 11 4.5-2 8-6 8-11V5z"/><path d="m9 12 2 2 4-4"/></svg></div>
        <h3>Paid Time Off</h3>
        <p>Generous annual leave, public holidays by location, and parental leave policies.</p>
      </div>
      <div class="benefit-card">
        <div class="ico"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg></div>
        <h3>Referral Rewards</h3>
        <p>Earn rewards for referring great talent into roles across any of our offices.</p>
      </div>
      <div class="benefit-card">
        <div class="ico"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/></svg></div>
        <h3>Modern Tools &amp; Tech</h3>
        <p>Work with the latest cloud, AI and collaboration tools — no outdated systems holding you back.</p>
      </div>
    </div>
  </div>
</section>

<!-- TEAM OUT / EVENTS -->
<section class="solutions">
  <div class="wrap">
    <div class="section-head">
      <div class="eyebrow">Team Out</div>
      <h2>Celebrations, outings &amp; team moments</h2>
      <p>A few snapshots from team events across our global offices.</p>
    </div>
    <div class="outings-grid">
      <div class="outing-card">
        <div class="outing-card-img">
          <img src="https://images.unsplash.com/photo-1530103862676-de8c9debad1d?auto=format&fit=crop&w=700&q=80" alt="Team outing on a beach">
        </div>
        <div class="outing-card-body">
          <span class="loc-tag">🇮🇳 Chennai, India</span>
          <h3>Annual team retreat at the coast</h3>
          <p>A two-day offsite combining strategy sessions with team-building activities by the sea.</p>
        </div>
      </div>
      <div class="outing-card">
        <div class="outing-card-img">
          <img src="https://images.unsplash.com/photo-1551632811-561732d1e306?auto=format&fit=crop&w=700&q=80" alt="Team dinner celebration in the US">
        </div>
        <div class="outing-card-body">
          <span class="loc-tag">🇺🇸 New Jersey, USA</span>
          <h3>Year-end team dinner</h3>
          <p>Celebrating wins and welcoming new team members over dinner with the North America team.</p>
        </div>
      </div>
      <div class="outing-card">
        <div class="outing-card-img">
          <img src="https://images.unsplash.com/photo-1518684079-3c830dcef090?auto=format&fit=crop&w=700&q=80" alt="Team at a desert event in Dubai">
        </div>
        <div class="outing-card-body">
          <span class="loc-tag">🇦🇪 Dubai, UAE</span>
          <h3>Desert team-building day</h3>
          <p>Our Dubai team swapped the office for a day of activities in the desert outside the city.</p>
        </div>
      </div>
      <div class="outing-card">
        <div class="outing-card-img">
          <img src="https://images.unsplash.com/photo-1565967511849-76a60a516170?auto=format&fit=crop&w=700&q=80" alt="Team at Marina Bay Singapore">
        </div>
        <div class="outing-card-body">
          <span class="loc-tag">🇸🇬 Singapore</span>
          <h3>Marina Bay welcome event</h3>
          <p>Marking the opening of our Singapore hub with a welcome event for the new local team.</p>
        </div>
      </div>
      <div class="outing-card">
        <div class="outing-card-img">
          <img src="https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=700&q=80" alt="Team event in Tokyo Japan">
        </div>
        <div class="outing-card-body">
          <span class="loc-tag">🇯🇵 Tokyo, Japan</span>
          <h3>Cherry blossom season gathering</h3>
          <p>Our Tokyo team's annual hanami gathering — a tradition the wider team looks forward to each year.</p>
        </div>
      </div>
      <div class="outing-card">
        <div class="outing-card-img">
          <img src="https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?auto=format&fit=crop&w=700&q=80" alt="Team event in Sydney Australia">
        </div>
        <div class="outing-card-body">
          <span class="loc-tag">🇦🇺 Sydney, Australia</span>
          <h3>Harbourside team lunch</h3>
          <p>Our Australia team came together for a lunch by Sydney Harbour to celebrate a strong quarter.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section class="skills bg-white">
  <div class="wrap">
    <div class="section-head center">
      <div class="eyebrow" style="justify-content:center;">In Their Words</div>
      <h2>What our team says about working here</h2>
      <p>A few thoughts from people across our global offices.</p>
    </div>
    <div class="testi-grid">
      <div class="testi-card">
        <div class="quote-mark">"</div>
        <p>I've worked on projects for clients in three different countries without ever feeling like I was on my own — the global team is genuinely connected.</p>
        <div class="who">Ananya R.<span>Software Engineer, Chennai</span></div>
      </div>
      <div class="testi-card">
        <div class="quote-mark">"</div>
        <p>The flexibility to work hybrid while staying close to a strong local team has made a real difference for my work-life balance.</p>
        <div class="who">James W.<span>Account Manager, Sydney</span></div>
      </div>
      <div class="testi-card">
        <div class="quote-mark">"</div>
        <p>Certifications, mentorship, and real ownership of projects early on — I've grown faster here than I expected.</p>
        <div class="who">Mei L.<span>Cloud Engineer, Singapore</span></div>
      </div>
    </div>
  </div>
</section>

<!-- CTA -->
<section class="cta" id="contact">
  <h2>Want to be part of the team?</h2>
  <p>Explore open roles across our global offices — or get in touch to learn more about life at AIT.</p>
  <div class="actions">
    <a href="<?= $base ?>https://vijaykrishna-ait.github.io/AITNEW/career" class="btn btn-lime">View Careers</a>
    <a href="<?= $base ?>#jobs" class="btn btn-outline-light">Browse Open Roles</a>
  </div>
</section>

  <?php include 'includes/footer.php'; ?>